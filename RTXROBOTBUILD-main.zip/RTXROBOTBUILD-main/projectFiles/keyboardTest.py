import getch

print(getch.getch())